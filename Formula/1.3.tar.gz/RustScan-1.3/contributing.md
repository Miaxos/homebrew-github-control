This is my first Rust project! As such, I expect there are many, many bugs involved or things that can be sped up.

If you're looking to get involved, we make use of Good First Issues / Help Wanted tags. Click this link to see all the issues we could use help with!
[https://github.com/brandonskerritt/RustScan/issues?q=is%3Aopen+is%3Aissue+label%3A%22help+wanted%22](https://github.com/brandonskerritt/RustScan/issues?q=is%3Aopen+is%3Aissue+label%3A%22help+wanted%22)

Please leave issues / pull requests, I'd love to learn more about this amazing language :) 
